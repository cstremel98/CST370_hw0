#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {

	int val = 0;
	vector<int> intVector (5);
	for(int i=0; i<5; i++) {
		//intVector.push_back(i);
		cin >> val;
		intVector.at(i)= val;
	}

	std::sort(intVector.begin(), intVector.end());

	/*for(int i=0; i<5; i++) {
		//cout << intVector[i];
		cout << intVector.at(i);
	}
	cout << endl;*/

	int min = intVector.at(0);
	int max = intVector.at(4);
	int median = intVector.at(2);

	cout << "MIN:" << min << endl;
	cout << "MAX:" << max << endl;
	cout << "MEDIAN:" << median << endl;

	return 0;
}
