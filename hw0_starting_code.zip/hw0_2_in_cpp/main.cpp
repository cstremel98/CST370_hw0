/*
 * INSTRUCTIONS:
 *     This is the starting C++ code for hw0_2.
 *     Note that the current filename is "main.cpp". 
 *     When you finish your development, copy the file.
 *     Then, rename the copied file to "main_hw0_2.cpp".
 *     After that, upload the renamed file to Canvas.
 */

// Finish the head comment with Abstract, ID, Name, and Date.
/*
 * Title: main.cpp
 * Abstract: Write the main purpose of the program.
 * ID: Write your 4-digit ID
 * Name: Write your name
 * Date: MM/DD/YYYY
 */

#include <iostream>
using namespace std;

int main() 
{
    // Develop your program here.
    // The following is just a sample statement.
    cout << "Hello World!" << endl;

    return 0;
}

