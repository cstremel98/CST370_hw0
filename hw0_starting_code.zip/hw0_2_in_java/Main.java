/*
 * INSTRUCTIONS:
 *     This is the starting Java code for hw0_2.
 *     Note that the current filename is "Main.java". 
 *     When you finish your development, copy the file.
 *     Then, rename the copied file to "Main_hw0_2.java".
 *     After that, upload the renamed file to Canvas.
 */

// Finish the head comment with Abstract, ID, Name, and Date.
/*
 * Title: Main.java
 * Abstract: Write the main purpose of the program.
 * ID: Write your 4-digit ID
 * Name: Write your name
 * Date: MM/DD/YYYY
 */

class Main 
{
    public static void main(String[] args) 
    {
        // Develop your program here.
        // The following is just a sample statement.
        System.out.println("Hello world!");
    }
}

